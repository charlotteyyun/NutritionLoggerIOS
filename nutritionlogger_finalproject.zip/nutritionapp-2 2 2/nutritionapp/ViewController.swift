//
//  ViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
 
    var datePicker: UIDatePicker!
    var foodlogged: [NSManagedObject] = []
    var goalsset: [NSManagedObject] = []
    var consumed: [Float] = [0,0,0,0,0,0]
    let nutrient_keys = ["calories", "carbs", "fiber", "sugar", "protein", "fat"]

    @IBOutlet weak var viewTitle: UINavigationItem!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var dashboardTable: UITableView!

    @IBOutlet weak var goalCalorieLabel: UILabel!
    @IBOutlet weak var consumedCalorieLabel: UILabel!
    @IBOutlet weak var remainingCalorieLabel: UILabel!
    override func viewDidLoad() {
        textField.delegate = self
        super.viewDidLoad()
        let date = Date()
        let format = DateFormatter()
        format.dateFormat = "MM/dd/yyyy"
        let formattedDate = format.string(from: date)
        textField.insertText(String(describing: formattedDate))
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action: #selector(ViewController.dateChanged(datePicker:)), for: .valueChanged)
        
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton], animated: false)
        
        textField.inputAccessoryView = toolbar
        textField.inputView = datePicker
        goalCalorieLabel.text = "0"
        consumedCalorieLabel.text = "0"
        remainingCalorieLabel.text = "0"

        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer){
        view.endEditing(true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2

        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "FoodLogged")
        let otherRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        fetchRequest.predicate = NSPredicate(format: "date == %@", textField.text!)

        //3
        do {
            foodlogged = try managedContext.fetch(fetchRequest)
            goalsset = try managedContext.fetch(otherRequest)
            self.dashboardTable.reloadData()
            consumed = [0,0,0,0,0,0]
            for food in foodlogged{
                for index in 0...nutrient_keys.count-1{
                    consumed[index] += (food.value(forKeyPath: nutrient_keys[index]) as! Float)*(food.value(forKeyPath: "amount") as! Float)
                }
            }
            consumedCalorieLabel.text = "\(Int(round(consumed[0])))"
            let count = goalsset.count
            if count == 0 {
                let entity =
                    NSEntityDescription.entity(forEntityName: "Goals",
                                               in: managedContext)!
                
                let goal = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
                goal.setValue(2000, forKeyPath: "caloriegoals")
                goal.setValue(3000, forKeyPath: "watergoals")
                goal.setValue(50, forKeyPath: "carbgoals")
                goal.setValue(30, forKeyPath: "protgoals")
                goal.setValue(20, forKeyPath: "fatgoals")
                do {
                    try managedContext.save()
                    goalsset.append(goal)
                    print(goalsset)
                    
                }
                catch
                    let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                    }
                }
            let goal = goalsset[0]
            goalCalorieLabel.text = "\(Int(round(goal.value(forKeyPath: "caloriegoals") as! Float)))"
            remainingCalorieLabel.text = "\(Int(round(goal.value(forKeyPath: "caloriegoals") as! Float)) - Int(round(consumed[0])))"
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
//    //MARK: table view source
//    func numberOfSections(in tableView: UITableView) -> Int {
//        //to add times?
//        return 1
//    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodlogged.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DashboardTableViewCell
        
    //take data
        let food = foodlogged[indexPath.row]
        let true_calories = (food.value(forKeyPath: "calories") as! Float)*(food.value(forKeyPath: "amount") as! Float)
        let true_amount = 100 * (food.value(forKeyPath: "amount") as! Float)
        cell.foodName.text = food.value(forKeyPath: "name") as? String
        cell.foodDescript.text = String(describing: Int(round(true_amount))) + " g"
        cell.calorieValue.text = String(describing: Int(round(true_calories))) + " kCal"
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            
            let managedContext =
                appDelegate.persistentContainer.viewContext
            do {
                managedContext.delete(foodlogged[indexPath.row])
                try managedContext.save()
            } catch let error as NSError {
                print("Could not delete. \(error), \(error.userInfo)")
            }
            
            foodlogged.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            viewWillAppear(true)

        }
}
    @objc func dateChanged(datePicker: UIDatePicker){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        textField.text = dateFormatter.string(from:datePicker.date)
        
    }
    @objc func cancelDatePicker(){
        viewWillAppear(true)
        self.view.endEditing(true)
        textField.resignFirstResponder()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDailyNutrition" {
            if segue.destination.isKind(of: DailyNutritionViewController.self) {
                let secondVC = segue.destination as! DailyNutritionViewController
                let index = dashboardTable.indexPathForSelectedRow?.row
                secondVC.passedValue = [self.foodlogged[index!]]
            }
        }
        if segue.identifier == "toOverview" {
            if segue.destination.isKind(of: GoalsViewController.self) {
                let secondVC = segue.destination as! GoalsViewController
                secondVC.passedValue = consumed
            }
        }
        if segue.identifier == "toFood" {
            if segue.destination.isKind(of: FoodViewController.self) {
                let secondVC = segue.destination as! FoodViewController
                secondVC.passedValue = textField.text!
            }
        }
}

    
    //MARK: table view delegate
//    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        let edit = editAction(at: indexPath)
//        return UISwipeActionsConfiguration(actions: [edit])
//    }
//
//    func editAction (at IndexPath: IndexPath) -> UIContextualAction {
//        let action = UIContextualAction(style: .destructive, title: "Edit") { (action, view, completion) in
//            print("edit tried")
//            //delete from core data
//            //segue
//            completion(true)
//        }
//        action.image = #imageLiteral(resourceName: "editicon")
//        action.backgroundColor = .purple
//        return action
//    }
//    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        let delete = deleteAction(at: indexPath)
//
//        return UISwipeActionsConfiguration(actions: [delete])
//    }
//
//    func deleteAction(at IndexPath: IndexPath) -> UIContextualAction {
//        let action = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completion) in
//            print("delete tried")
//        //delete from core data
//        self.dashboardTable.deleteRows(at: [IndexPath], with: .automatic)
//            completion(true)
//    }
//        action.image = #imageLiteral(resourceName: "trash")
//        action.backgroundColor = .red
//        return action
//    }
//
//
//
//}

}
