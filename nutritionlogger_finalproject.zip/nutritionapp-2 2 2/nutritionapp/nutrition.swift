//
//  nutrition.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 5/3/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

struct nutrition {
    var calories: Int
    var carbs: Int
    var protein: Int
    var fat: Int
    var fiber: Int
    var sugar: Int
    var measurement: String

}
