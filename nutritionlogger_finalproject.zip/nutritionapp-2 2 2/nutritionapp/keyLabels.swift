//
//  keyLabels.swift
//  nutritionapp
//
//  Created by Andreeva, Anna-maria K on 5/13/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

@IBDesignable class keyLabels: UIView {
    @IBInspectable var actualColor: UIColor = UIColor.purple
    @IBInspectable var goalColor: UIColor = UIColor.gray
    
    override func draw(_ rect: CGRect) {
        let width = 20
        let actual = UIBezierPath()
        let x = 150
        let y = 23
        actual.move(to: CGPoint(x: x-5, y: y))
        actual.addLine(to: CGPoint(x: x + width, y: y))
        actualColor.setStroke()
        actual.lineWidth = 4.0
        actual.stroke()
        let goal = UIBezierPath()
        goal.move(to: CGPoint(x: x-17, y: y + 28))
        goal.addLine(to: CGPoint(x: x + width-12, y: y + 28))
        
        goalColor.setStroke()
        goal.lineWidth = 4.0
        goal.stroke()
    }
    
}
