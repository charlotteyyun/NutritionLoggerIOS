//
//  GoalsViewController.swift
//  nutritionapp
//
//  Created by Anna-Maria Andreeva on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class GoalsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    var pickOption = [["0 %", "5 %", "10 %", "15 %", "20 %", "25 %", "30 %", "35 %", "40 %", "45 %", "50 %", "55 %", "60 %", "65 %", "70 %", "75 %", "80 %", "85 %", "90 %", "95 %", "100 %"], ["0 %", "5 %", "10 %", "15 %", "20 %", "25 %", "30 %", "35 %", "40 %", "45 %", "50 %", "55 %", "60 %", "65 %", "70 %", "75 %", "80 %", "85 %", "90 %", "95 %", "100 %"],["0 %", "5 %", "10 %", "15 %", "20 %", "25 %", "30 %", "35 %", "40 %", "45 %", "50 %", "55 %", "60 %", "65 %", "70 %", "75 %", "80 %", "85 %", "90 %", "95 %", "100 %"]]
    var labelTexts = ["Carbs", "Protein", "Fat"]
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calorieGoal: UITextField!
    @IBOutlet weak var waterGoal: UITextField!
    @IBOutlet weak var myButton: MyButton!
    var allgoals: [NSManagedObject] = []
    let nutrient_names = ["Calories (kCal)", "Carbs (g)", "       Fiber (g)", "       Sugar (g)", "Protein (g)", "Fat (g)"]
    var passedValue:[Float] = [0,0,0,0,0,0]
    var goalValues: [Float] = [0,0,0,0,0,0]
    var goalsset: [NSManagedObject] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        calorieGoal.delegate = self
        waterGoal.delegate = self
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        let otherRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        
        //3
        do {
            goalsset = try managedContext.fetch(otherRequest)
            let count = goalsset.count
            if count == 0 {
                let entity =
                    NSEntityDescription.entity(forEntityName: "Goals",
                                               in: managedContext)!
                
                let goal = NSManagedObject(entity: entity,
                                               insertInto: managedContext)
                goal.setValue(2000, forKeyPath: "caloriegoals")
                goal.setValue(3000, forKeyPath: "watergoals")
                goal.setValue(50, forKeyPath: "carbgoals")
                goal.setValue(30, forKeyPath: "protgoals")
                goal.setValue(20, forKeyPath: "fatgoals")
                do {
                    try managedContext.save()
                    goalsset.append(goal)
                    print(goalsset)
                    
                }
                catch
                    let error as NSError {
                        print("Could not save. \(error), \(error.userInfo)")
                }
            }
            let entityobj = goalsset[0]
            goalValues[0] = entityobj.value(forKey: "caloriegoals") as! Float
            let carbp = entityobj.value(forKey: "carbgoals") as! Float
            let protp = entityobj.value(forKey: "protgoals") as! Float
            let fatp = entityobj.value(forKey: "fatgoals") as! Float
            goalValues[1] = (Float(carbp)/100)*goalValues[0]/4
            goalValues[4] = (Float(protp)/100)*goalValues[0]/4
            goalValues[5] = (Float(fatp)/100)*goalValues[0]/9
            tableView.reloadData()
            
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        
    }

    @IBAction func saveButton(_ sender: UIButton) {
        if calorieGoal.text != nil && waterGoal.text != nil {
            let calories = (calorieGoal.text! as NSString).integerValue
            let waters = (waterGoal.text! as NSString).integerValue
            
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            print ("save button")
            // 1
            let managedContext =
                appDelegate.persistentContainer.viewContext
            print ("managecontext")
            
            let entityobj = goalsset[goalsset.count-1]
            if calorieGoal.text != "" {
                entityobj.setValue(calories, forKeyPath: "caloriegoals")
            }
            if waterGoal.text != "" {
                entityobj.setValue(waters, forKeyPath: "watergoals")
            }

            do {
                try managedContext.save()
                goalsset[0] = entityobj
                print(goalsset)
                let alert = UIAlertView()
                alert.title = "Saved"
                alert.addButton(withTitle: "OK")
                alert.show()
                goalValues[0] = Float(calories)
                let carbp = entityobj.value(forKey: "carbgoals") as! Float
                let protp = entityobj.value(forKey: "protgoals") as! Float
                let fatp = entityobj.value(forKey: "fatgoals") as! Float
                goalValues[1] = (Float(carbp)/100)*goalValues[0]/4
                goalValues[4] = (Float(protp)/100)*goalValues[0]/4
                goalValues[5] = (Float(fatp)/100)*goalValues[0]/9
                tableView.reloadData()
                
            }
            catch
                let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
            }
            
        }
        else{
            let alert = UIAlertView()
            alert.title = "Error, please insert numbers"
            alert.show()
        }
    }
    @IBAction func buttonClicked(_ sender: MyButton) {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton], animated: false)
        
        myButton.inputAccessoryView = toolbar
        myButton.inputView = pickerView
        let labelWidth = self.view.frame.width / CGFloat(pickerView.numberOfComponents)
        
        for index in 0..<labelTexts.count {
            let label: UILabel = UILabel.init(frame: CGRect(x: pickerView.frame.origin.x + labelWidth * CGFloat(index), y: 0, width: labelWidth, height: 40))
            label.text = labelTexts[index]
            label.textAlignment = .center
            pickerView.addSubview(label)
        }
        let label: UILabel = UILabel.init(frame: CGRect(x: pickerView.frame.origin.x, y: pickerView.frame.height - 40, width: self.view.frame.width, height: 40))
        label.text = "Sum of macros must equal 100%"
        label.textColor = UIColor.red
        label.textAlignment = .center
        pickerView.addSubview(label)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nutrient_names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! NutritionTableViewCell
        cell.nutrientLabel.text = nutrient_names[indexPath.row]
        cell.valueLabel.text = "\(Int(round(passedValue[indexPath.row])))"
        if goalValues[indexPath.row] == 0 {
            cell.goalLabel.text = "-"
        }
        else{
            cell.goalLabel.text = "\(Int(round(goalValues[indexPath.row])))"
        }
        return cell
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return pickOption.count
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickOption[component].count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickOption[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let carb = pickOption[0][pickerView.selectedRow(inComponent: 0)]
        let protein = pickOption[1][pickerView.selectedRow(inComponent: 1)]
        let fat = pickOption[2][pickerView.selectedRow(inComponent: 2)]
        let carbp = Int(carb.split(separator: " ")[0])!
        let protp = Int(protein.split(separator: " ")[0])!
        let fatp = Int(fat.split(separator: " ")[0])!
        
        if carbp + protp + fatp == 100{
            pickerView.subviews[4].isHidden = true
            goalValues[1] = (Float(carbp)/100)*goalValues[0]/4
            goalValues[4] = (Float(protp)/100)*goalValues[0]/4
            goalValues[5] = (Float(fatp)/100)*goalValues[0]/9
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            // 1
            let managedContext =
                appDelegate.persistentContainer.viewContext
            
            let entityobj = goalsset[goalsset.count-1]
            entityobj.setValue(Float(carbp), forKeyPath: "carbgoals")
            entityobj.setValue(Float(protp), forKeyPath: "protgoals")
            entityobj.setValue(Float(fatp), forKeyPath: "fatgoals")
            
            do {
                try managedContext.save()
                goalsset[0] = entityobj
                print(goalsset)
                
            }
            catch
                let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
            }
            tableView.reloadData()
        }
        else {
            pickerView.subviews[4].isHidden = false
            
            
        }
    }
    @objc func cancelDatePicker(){
        viewWillAppear(true)
        self.view.endEditing(true)
        myButton.resignFirstResponder()
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
