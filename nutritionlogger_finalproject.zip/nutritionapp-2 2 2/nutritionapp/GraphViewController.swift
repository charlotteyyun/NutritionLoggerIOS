//
//  GraphViewController.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 5/9/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit
import CoreData

class GraphViewController: UIViewController {
    
//    let calorieView: UIView!

    @IBOutlet weak var segments: UISegmentedControl!
    @IBOutlet weak var keyLabels: UIView!
    @IBAction func segmentControl(_ sender: Any) {
        
        let getIndex = segments.selectedSegmentIndex
        print(getIndex)
        switch (getIndex){
        case 0:
            typeLabel.text = "Water Consumed"
            setupWaterGraphDisplay()
            graphView.setNeedsDisplay()
        case 1:
            typeLabel.text = "Calories Consumed"
            setupCaloriesGraphDisplay()
            graphView.setNeedsDisplay()
        default:
            print("no select")
        }
    }
    
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var graphAverage: UILabel!
    @IBOutlet weak var graphView: GraphView!
    @IBOutlet weak var averageWaterDrunk: UILabel!
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var typeLabel: UILabel!
    var goalsset: [NSManagedObject] = []
    var calset: [NSManagedObject] = []
    var waterset: [NSManagedObject] = []
    var waterConsumed: Int = 0
    var waterGoal: Int = 0
    var caloriesConsumed: Int = 0
    var caloriesGoal: Int = 0
    var week: [String] = ["","","","","","",""]
    var weeklywater: [Int] = [0,0,0,0,0,0,0]
    var weeklycalories: [Int] = [0,0,0,0,0,0,0]

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let currentdate = Date()
        for x in 0...6 {
            let date = Calendar.current.date(byAdding: .day, value: -x, to: currentdate)!
            let format = DateFormatter()
            format.dateFormat = "MM/dd/yyyy"
            let formattedDate = format.string(from: date)
            week[x] = formattedDate
        }
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Goals")
        let caloriefetch = NSFetchRequest<NSManagedObject>(entityName: "FoodLogged")
        let waterfetch = NSFetchRequest<NSManagedObject>(entityName: "WaterLogged")
        
        do {
            goalsset = try managedContext.fetch(fetchRequest)
            let count = goalsset.count
            if count != 0 {
                let goal = goalsset[count-1]
                
                if goal.value(forKeyPath: "watergoals") != nil {
                    waterGoal = goal.value(forKeyPath: "watergoals") as! Int
                }
                
                if goal.value(forKeyPath: "caloriegoals") != nil {
                    caloriesGoal = goal.value(forKeyPath: "caloriegoals") as! Int
                }
            }
            weeklywater = [0,0,0,0,0,0,0]
            weeklycalories = [0,0,0,0,0,0,0]
            for x in 0...6 {
                caloriefetch.predicate = NSPredicate(format: "date == %@", week[x])
                calset = try managedContext.fetch(caloriefetch)
                for food in calset{
                    weeklycalories[x] += (food.value(forKeyPath: "calories") as! Int)*(food.value(forKeyPath: "amount") as! Int)
                }
                waterfetch.predicate = NSPredicate(format: "date == %@", week[x])
                waterset = try managedContext.fetch(waterfetch)
                if waterset.count != 0 {
                    weeklywater[x] = waterset[0].value(forKeyPath: "water") as! Int                }
            }
            print(waterGoal)
            print(caloriesGoal)
            print(weeklycalories)
            print(weeklywater)
        }
        catch
            let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo))")
        }
        setupWaterGraphDisplay()
//        graphView.setNeedsDisplay()
    }
    
    func setupWaterGraphDisplay() {
        unitLabel.text = "mL"
        segments.tintColor = UIColor.init(red: 0.105, green: 0.733, blue: 1, alpha: 1)
        let maxDayIndex = stackView.arrangedSubviews.count - 1
        graphView.startColor = .init(red: 0.105, green: 0.733, blue: 1, alpha: 1)
        graphView.endColor = .init(red: 0.878, green: 0.984, blue: 1, alpha: 1)
        
        print(graphView.consumedPoints)
        print(waterConsumed)
        graphView.consumedPoints = weeklywater.reversed()
        graphView.goalPoints = [waterGoal,waterGoal,waterGoal,waterGoal,waterGoal,waterGoal,waterGoal]
        graphView.setNeedsDisplay()
        let max = ([graphView.goalPoints.max()!,graphView.consumedPoints.max()!]).max()!
        maxLabel.text = "\(max)"
        
        let average = graphView.consumedPoints.reduce(0, +) / graphView.consumedPoints.count
        averageWaterDrunk.text = "\(average) mL"
        graphAverage.text = "\(max/2)"
        
        let today = Date()
        let calendar = Calendar.current
        
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("EEEEE")
        
        for i in 0...maxDayIndex {
            if let date = calendar.date(byAdding: .day, value: -i, to: today),
                let label = stackView.arrangedSubviews[maxDayIndex - i] as? UILabel {
                label.text = formatter.string(from: date)
            }
        }
        graphView.setNeedsDisplay()
    }
    func setupCaloriesGraphDisplay() {
        unitLabel.text = "kCal"
        segments.tintColor = UIColor.init(red: 1, green: 0.682, blue: 0.255, alpha: 1)
        let maxDayIndex = stackView.arrangedSubviews.count - 1
        graphView.startColor = .init(red: 1, green: 0.682, blue: 0.255, alpha: 1)
        graphView.endColor = .init(red: 1, green: 0.92, blue: 0.86, alpha: 1)
        
        graphView.consumedPoints = weeklycalories.reversed()
        graphView.goalPoints = [caloriesGoal,caloriesGoal,caloriesGoal,caloriesGoal,caloriesGoal,caloriesGoal,caloriesGoal]
        
        let max = ([graphView.goalPoints.max()!,graphView.consumedPoints.max()!]).max()!
        graphView.setNeedsDisplay()
        maxLabel.text = "\(max)"
        
        let average = graphView.consumedPoints.reduce(0, +) / graphView.consumedPoints.count
        averageWaterDrunk.text = "\(average) kCal"
        graphAverage.text = "\(max/2)"
        
        let today = Date()
        let calendar = Calendar.current
        
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("EEEEE")
        
        for i in 0...maxDayIndex {
            if let date = calendar.date(byAdding: .day, value: -i, to: today),
                let label = stackView.arrangedSubviews[maxDayIndex - i] as? UILabel {
                label.text = formatter.string(from: date)
            }
        }
        graphView.setNeedsDisplay()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupWaterGraphDisplay()
//        graphView.setNeedsDisplay()
    

        // Do any additional setup after loading the view.
    }
    
    
}
