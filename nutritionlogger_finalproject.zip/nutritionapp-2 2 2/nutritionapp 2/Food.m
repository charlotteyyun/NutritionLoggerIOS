//
//  Food.m
//  nutritionapp
//
//  Created by Yun, Yeji on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

#import "Food.h"

@implementation Food

@end
